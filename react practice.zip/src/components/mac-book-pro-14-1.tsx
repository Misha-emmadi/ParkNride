import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const MacBookPro141: FunctionComponent = () => {
  const navigate = useNavigate();

  const onGroupContainer4Click = useCallback(() => {
    navigate("/macbook-pro-14-2");
  }, [navigate]);

  return (
    <div className="relative bg-white w-full h-[992px] overflow-y-auto text-left text-5xl text-black font-inria-serif">
      <div className="absolute top-[12px] left-[32px] w-[1483px] h-[2272px]">
        <img
          className="absolute top-[0px] left-[0px] w-[137px] h-[134px] object-cover"
          alt=""
          src="/image-2@2x.png"
        />
        <div className="absolute top-[67px] left-[calc(50%_-_380.5px)] w-[1100px] h-[68px] font-inter">
          <div className="absolute top-[0px] left-[calc(50%_+_337px)] rounded-35xl bg-gold-100 w-[199px] h-[68px]" />
          <div className="absolute top-[23px] left-[calc(50%_+_354px)] inline-block w-[196px] h-[45px]">
            Download app
          </div>
          <div className="absolute top-[14px] left-[calc(50%_-_550px)] inline-block w-[91px] h-10">
            Home
          </div>
          <div className="absolute top-[16px] left-[calc(50%_-_432px)] inline-block w-28 h-[21px]">
            About us
          </div>
          <div className="absolute top-[16px] left-[calc(50%_-_296px)] inline-block w-[133px] h-[18px]">
            Be a seller
          </div>
          <div className="absolute top-[16px] left-[calc(50%_-_141px)] inline-block w-[209px] h-[19px]">
            Customer service
          </div>
        </div>
        <b className="absolute h-[calc(100%_-_2049px)] w-[calc(100%_-_1078px)] top-[251px] left-[1021px] text-29xl inline-block">
          Parking made easier with Park’N Ride
        </b>
        <div className="absolute top-[479px] left-[1245px] w-[198px] h-[88px]">
          <div className="absolute top-[0px] left-[0px] rounded-22xl bg-gainsboro-100 w-[198px] h-[86px]" />
          <b className="absolute top-[2px] left-[25px] inline-block w-[157px] h-[86px]">
            Earn through parnride
          </b>
        </div>
        <div className="absolute h-[calc(100%_-_230px)] top-[230px] bottom-[0px] left-[14px] w-[1469px] text-13xl">
          <img
            className="absolute h-[calc(100%_-_1431px)] top-[0px] bottom-[1431px] left-[0px] rounded-41xl max-h-full w-[1001px] object-cover"
            alt=""
            src="/rectangle-2@2x.png"
          />
          <div className="absolute top-[752px] left-[28px] w-[1441px] h-[1290px]">
            <div className="absolute top-[0px] left-[469px] rounded-65xl bg-gold-200 shadow-[-25px_38px_64px_rgba(0,_0,_0,_0.25)] w-[972px] h-[552px]" />
            <div className="absolute top-[179px] left-[45px] rounded-16xl bg-gainsboro-100 w-[355px] h-[82px]" />
            <div className="absolute top-[298px] left-[45px] rounded-16xl bg-gainsboro-100 w-[355px] h-[82px]" />
            <b className="absolute top-[200px] left-[98px] inline-block w-[273px] h-10">
              Enter location
            </b>
            <b className="absolute top-[317px] left-[98px] inline-block w-60 h-12">
              Type of vehicle
            </b>
            <div className="absolute top-[738px] left-[0px] rounded-41xl bg-gold-200 shadow-[24px_27px_22px_rgba(0,_0,_0,_0.25)] w-[936px] h-[552px]" />
            <b className="absolute top-[801px] left-[974px] text-21xl inline-block w-[467px] h-[147px]">
              Make money by renting out your parking spaces
            </b>
            <div className="absolute top-[1054px] left-[991px] rounded-27xl bg-gainsboro-100 w-[259px] h-[74px]" />
            <b className="absolute top-[1067px] left-[1010px] text-21xl inline-block w-60 h-[61px]">
              Get started
            </b>
            <b className="absolute top-[112px] left-[47px] inline-block w-[390px] h-[59px]">
              Check Our Prices
            </b>
            <img
              className="absolute top-[1732px] left-[74px] rounded-42xl w-[936px] h-[552px] object-cover"
              alt=""
              src="/image-3@2x.png"
            />
          </div>
          <img
            className="absolute top-[994px] left-[543px] rounded-58xl w-[972px] h-[552px] object-cover"
            alt=""
            src="/image-21@2x.png"
          />
        </div>
        <img
          className="absolute top-[118.5px] left-[361px] w-[72.8px] h-[5px]"
          alt=""
          src="/line-1.svg"
        />
        <div
          className="absolute top-[481px] left-[1025px] w-[198px] h-[86px] cursor-pointer"
          onClick={onGroupContainer4Click}
        >
          <div className="absolute top-[0px] left-[0px] rounded-22xl bg-gainsboro-100 w-[198px] h-[86px]" />
          <b className="absolute top-[0px] left-[20px] inline-block w-[149px] h-[62px]">{`Find a parking spot `}</b>
        </div>
      </div>
    </div>
  );
};

export default MacBookPro141;
