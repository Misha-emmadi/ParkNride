import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const MacBookPro1412: FunctionComponent = () => {
  const navigate = useNavigate();

  const onRectangle2Click = useCallback(() => {
    navigate("/macbook-pro-14-13");
  }, [navigate]);

  return (
    <div className="relative bg-white w-full h-[982px] overflow-hidden text-left text-29xl text-black font-inter">
      <div className="absolute top-[23px] left-[0px] w-[1825px] h-[1414px] text-21xl">
        <img
          className="absolute top-[0px] left-[35px] w-[137px] h-[134px] object-cover"
          alt=""
          src="/image-2@2x.png"
        />
        <img
          className="absolute top-[128.5px] left-[0px] w-[1502px] h-2"
          alt=""
          src="/line-6.svg"
        />
        <div className="absolute top-[12px] left-[296px] inline-block w-[290px] h-[61px]">
          Book your slot
        </div>
        <div className="absolute top-[12px] left-[648px] inline-block w-[346px] h-8">
          Customer service
        </div>
        <div className="absolute top-[182px] left-[30px] rounded-42xl bg-white w-[472px] h-[485px]" />
        <div className="absolute top-[159px] left-[586px] w-[891px] h-[767px] overflow-hidden" />
        <img
          className="absolute top-[134px] left-[545px] w-[1280px] h-[1280px] object-cover"
          alt=""
          src="/basemap-image@2x.png"
        />
        <img
          className="absolute top-[0px] left-[1297px] w-[86px] h-[84px]"
          alt=""
          src="/group-8.svg"
        />
        <img
          className="absolute h-[3.32%] w-[3.68%] top-[1.27%] right-[19.06%] bottom-[95.41%] left-[77.26%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/-icon-chevron-bottom.svg"
        />
      </div>
      <div className="absolute top-[349px] left-[0px] rounded-57xl bg-gainsboro-100 w-[545px] h-[633px]" />
      <div
        className="absolute top-[842px] left-[15px] rounded-35xl bg-black w-[502px] h-[107px] cursor-pointer"
        onClick={onRectangle2Click}
      />
      <b className="absolute top-[399px] left-[52px] inline-block w-[417px] h-[119px]">
        Basic bakery,Rtc x roads
      </b>
      <div className="absolute top-[562px] left-[38px] whitespace-pre-wrap inline-block w-[431px] h-[235px]">
        <p className="m-0"> Rated 4.5 by 125 users</p>
        <p className="m-0">{`      Your vehicle is safe and secure `}</p>
      </div>
      <div className="absolute top-[866px] left-[83px] text-white inline-block w-[386px] h-[59px]">
        Book Spot
      </div>
      <img
        className="absolute top-[562px] left-[28px] w-[76px] h-[75px] object-cover"
        alt=""
        src="/double-right@2x.png"
      />
      <img
        className="absolute top-[666px] left-[28px] w-[76px] h-[75px] object-cover"
        alt=""
        src="/double-right@2x.png"
      />
      <img
        className="absolute h-[6.52%] w-[4.23%] top-[88.19%] right-[68.98%] bottom-[5.3%] left-[26.79%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector6.svg"
      />
    </div>
  );
};

export default MacBookPro1412;
