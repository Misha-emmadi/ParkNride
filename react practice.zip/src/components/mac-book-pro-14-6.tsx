import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const MacBookPro146: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSearchTextClick = useCallback(() => {
    navigate("/macbook-pro-14-9");
  }, [navigate]);

  return (
    <div className="relative bg-white w-full h-[982px] overflow-hidden text-left text-21xl text-black font-inter">
      <div className="absolute top-[23px] left-[0px] w-[1825px] h-[1414px]">
        <img
          className="absolute top-[0px] left-[35px] w-[137px] h-[134px] object-cover"
          alt=""
          src="/image-2@2x.png"
        />
        <img
          className="absolute top-[128.5px] left-[0px] w-[1502px] h-2"
          alt=""
          src="/line-6.svg"
        />
        <div className="absolute top-[12px] left-[296px] inline-block w-[290px] h-[61px]">
          Book your slot
        </div>
        <div className="absolute top-[12px] left-[648px] inline-block w-[346px] h-8">
          Customer service
        </div>
        <div className="absolute top-[182px] left-[30px] rounded-42xl bg-white w-[472px] h-[485px]" />
        <div className="absolute top-[215px] left-[76px] inline-block w-[322px] h-[61px]">
          Book a spot
        </div>
        <div className="absolute top-[308px] left-[65px] rounded-2xs bg-whitesmoke-200 w-[417px] h-[69px]" />
        <div className="absolute top-[434px] left-[65px] rounded-2xs bg-whitesmoke-200 w-[417px] h-[69px]" />
        <div className="absolute top-[308px] left-[204px] inline-block w-[278px] h-10">
          Your location
        </div>
        <div className="absolute top-[437px] left-[154px] inline-block w-[313px] h-[66px]">
          Two wheeler
        </div>
        <div className="absolute top-[159px] left-[586px] w-[891px] h-[767px] overflow-hidden" />
        <img
          className="absolute top-[134px] left-[545px] w-[1280px] h-[1280px] object-cover"
          alt=""
          src="/basemap-image@2x.png"
        />
        <img
          className="absolute h-[4.74%] w-[2.9%] top-[21.92%] right-[91.56%] bottom-[73.34%] left-[5.53%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/-icon-map-marker1.svg"
        />
        <img
          className="absolute top-[0px] left-[1297px] w-[86px] h-[84px]"
          alt=""
          src="/group-81.svg"
        />
        <img
          className="absolute h-[3.32%] w-[3.68%] top-[1.27%] right-[19.06%] bottom-[95.41%] left-[77.26%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/-icon-chevron-bottom.svg"
        />
        <div className="absolute top-[551px] left-[120px] rounded-21xl bg-black w-[291px] h-[55px]" />
        <div
          className="absolute top-[551px] left-[192px] text-white inline-block w-[188px] h-[47px] cursor-pointer"
          onClick={onSearchTextClick}
        >
          Search
        </div>
      </div>
    </div>
  );
};

export default MacBookPro146;
