import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const MacBookPro1410: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBasicBakery50Click = useCallback(() => {
    navigate("/macbook-pro-14-12");
  }, [navigate]);

  return (
    <div className="relative bg-white w-full h-[982px] overflow-hidden text-left text-21xl text-black font-inter">
      <div className="absolute top-[23px] left-[0px] w-[1825px] h-[1414px]">
        <img
          className="absolute top-[0px] left-[35px] w-[137px] h-[134px] object-cover"
          alt=""
          src="/image-2@2x.png"
        />
        <img
          className="absolute top-[128.5px] left-[0px] w-[1502px] h-2"
          alt=""
          src="/line-6.svg"
        />
        <div className="absolute top-[12px] left-[296px] inline-block w-[290px] h-[61px]">
          Book your slot
        </div>
        <div className="absolute top-[12px] left-[648px] inline-block w-[346px] h-8">
          Customer service
        </div>
        <div className="absolute top-[159px] left-[586px] w-[891px] h-[767px] overflow-hidden">
          <div className="absolute top-[226px] left-[4px] bg-gainsboro-100 w-[296px] h-[85px]" />
          <div className="absolute top-[158px] left-[-85px] w-[250px] h-[127px]">
            <b className="absolute top-[0px] left-[0px] inline-block w-[250px] h-[127px]">
              <p className="m-0">Sahara bakery,</p>
              <p className="m-0">Rtc x roads</p>
            </b>
          </div>
        </div>
        <img
          className="absolute top-[134px] left-[545px] w-[1280px] h-[1280px] object-cover"
          alt=""
          src="/basemap-image@2x.png"
        />
        <img
          className="absolute top-[0px] left-[1297px] w-[86px] h-[84px]"
          alt=""
          src="/group-8.svg"
        />
        <img
          className="absolute h-[3.32%] w-[3.68%] top-[1.27%] right-[19.06%] bottom-[95.41%] left-[77.26%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/-icon-chevron-bottom.svg"
        />
        <b className="absolute top-[261px] left-[35px] inline-block w-[330px] h-[124px]">
          Choose your spot
        </b>
        <div className="absolute top-[595px] left-[566px] rounded-16xl bg-gainsboro-100 w-[379px] h-[179px]" />
        <b className="absolute top-[161px] left-[27px] inline-block w-[474px] h-[100px]">
          Three Wheeler
        </b>
        <div
          className="absolute top-[410px] left-[0px] font-medium whitespace-pre-wrap inline-block w-[518px] h-[110px] cursor-pointer"
          onClick={onBasicBakery50Click}
        >
          <p className="m-0">Basic bakery, 50</p>
          <p className="m-0">Rtc X roads per hour</p>
        </div>
        <div className="absolute top-[583px] left-[0px] font-medium whitespace-pre-wrap inline-block w-[545px] h-[135px]">
          <p className="m-0">openarms mall, 70</p>
          <p className="m-0">musheerabad per hour</p>
        </div>
        <div className="absolute top-[750px] left-[0px] font-medium whitespace-pre-wrap inline-block w-[518px] h-[107px]">
          <p className="m-0">Sam apts, 30</p>
          <p className="m-0">Rtc x roads per hour</p>
        </div>
        <img
          className="absolute top-[404px] left-[396px] w-[67px] h-[38px] object-cover"
          alt=""
          src="/rupee1@2x.png"
        />
        <img
          className="absolute top-[583px] left-[396px] w-[67px] h-[39px] object-cover"
          alt=""
          src="/rupee2@2x.png"
        />
        <img
          className="absolute top-[750px] left-[396px] w-[45px] h-[39px] object-cover"
          alt=""
          src="/rupee3@2x.png"
        />
      </div>
    </div>
  );
};

export default MacBookPro1410;
