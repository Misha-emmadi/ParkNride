import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const MacBookPro142: FunctionComponent = () => {
  const navigate = useNavigate();

  const onRectangle2Click = useCallback(() => {
    navigate("/macbook-pro-14-3");
  }, [navigate]);

  return (
    <div className="relative bg-white w-full h-[982px] overflow-hidden text-left text-21xl text-black font-inter">
      <div className="absolute top-[23px] left-[35px] w-[1386px] h-[596px]">
        <img
          className="absolute top-[0px] left-[0px] w-[137px] h-[134px] object-cover"
          alt=""
          src="/image-2@2x.png"
        />
        <div className="absolute top-[33px] left-[calc(50%_-_407px)] w-[1100px] h-[68px] text-5xl">
          <div className="absolute top-[0px] left-[calc(50%_+_337px)] rounded-35xl bg-gold-100 w-[199px] h-[68px]" />
          <div className="absolute top-[23px] left-[calc(50%_+_354px)] inline-block w-[196px] h-[45px]">
            Download app
          </div>
          <div className="absolute top-[14px] left-[calc(50%_-_550px)] inline-block w-[91px] h-10">
            Home
          </div>
          <div className="absolute top-[16px] left-[calc(50%_-_432px)] inline-block w-28 h-[21px]">
            About us
          </div>
          <div className="absolute top-[16px] left-[calc(50%_-_296px)] inline-block w-[133px] h-[18px]">
            Be a seller
          </div>
          <div className="absolute top-[16px] left-[calc(50%_-_141px)] inline-block w-[209px] h-[19px]">
            Customer service
          </div>
        </div>
        <div className="absolute top-[283px] left-[363px] inline-block w-[611px] h-[76px]">
          What is your phone number?
        </div>
        <div className="absolute top-[405px] left-[371px] w-[533px] h-[78px] text-lavenderblush">
          <div className="absolute top-[0px] left-[0px] rounded-27xl bg-gainsboro-100 w-[533px] h-[78px]" />
          <div className="absolute top-[7px] left-[40px] inline-block w-[493px] h-[58px]">
            Enter you mobile number
          </div>
        </div>
        <div
          className="absolute top-[536px] left-[464px] rounded-97xl bg-gold-200 w-[348px] h-[60px] cursor-pointer"
          onClick={onRectangle2Click}
        />
        <div className="absolute top-[536px] left-[505px] inline-block w-[190px] h-[50px]">
          Continue
        </div>
      </div>
    </div>
  );
};

export default MacBookPro142;
