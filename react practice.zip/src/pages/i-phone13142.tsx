import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const IPhone13142: FunctionComponent = () => {
  const navigate = useNavigate();

  const onGroupContainerClick = useCallback(() => {
    navigate("/iphone-13-14-3");
  }, [navigate]);

  return (
    <div className="relative rounded-30xl bg-black w-full h-[52.75rem] overflow-hidden text-left text-[1.75rem] text-black font-istok-web">
      <div className="absolute top-[3.69rem] left-[0rem] w-[24.38rem] h-[49.06rem]">
        <div className="absolute top-[10.38rem] left-[0rem] rounded-24xl bg-gainsboro-100 w-[24.38rem] h-[38.69rem]" />
        <div className="absolute top-[20.13rem] left-[2.06rem] rounded-[26px] bg-white w-[20.25rem] h-[5.13rem]" />
        <div className="absolute top-[15rem] left-[2.19rem] inline-block w-[15.81rem] h-[2rem]">
          Enter your mobile number
        </div>
        <div className="absolute top-[20.13rem] left-[2.06rem] rounded-4xl bg-gainsboro-100 w-[5.75rem] h-[5.13rem]" />
        <div className="absolute top-[21.81rem] left-[2.88rem] inline-block w-[2.75rem] h-[1.69rem]">
          +91
        </div>
        <div className="absolute top-[21.81rem] left-[10.13rem] text-[1.25rem] text-lightcyan inline-block w-[11rem] h-[2.94rem]">
          Mobile number
        </div>
        <div className="absolute top-[40.81rem] left-[1.31rem] bg-gainsboro-100 w-[0.88rem] h-[1.25rem]" />
        <div
          className="absolute top-[42.06rem] left-[2.19rem] w-[20.19rem] h-[3.81rem] cursor-pointer text-[2rem] text-white font-irish-grover"
          onClick={onGroupContainerClick}
        >
          <div className="absolute top-[0rem] left-[0rem] rounded-11xl bg-cornflowerblue w-[20.19rem] h-[3.81rem]" />
          <div className="absolute top-[0.69rem] left-[2.75rem] inline-block w-[11.19rem] h-[2.44rem]">
            Receive OTP
          </div>
          <img
            className="absolute h-[57.21%] w-[16.1%] top-[18.03%] right-[4.02%] bottom-[24.75%] left-[79.88%] max-w-full overflow-hidden max-h-full"
            alt=""
            src="/-icon-chevron-right.svg"
          />
        </div>
        <img
          className="absolute top-[20.94rem] left-[0.38rem] w-[3.38rem] h-[3.5rem] overflow-hidden"
          alt=""
          src="/keyboard-arrow-down.svg"
        />
        <div className="absolute top-[0rem] left-[3.31rem] text-[3rem] font-jejuhallasan text-white inline-block w-[18.25rem] h-[3.5rem]">
          Park’N Ride
        </div>
      </div>
    </div>
  );
};

export default IPhone13142;
