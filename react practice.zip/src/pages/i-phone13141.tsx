import { FunctionComponent } from "react";

const IPhone13141: FunctionComponent = () => {
  return (
    <div className="relative rounded-30xl bg-lightcyan w-full h-[52.75rem] overflow-hidden flex flex-col items-end justify-start py-[3.31rem] px-[0rem] box-border text-left text-[3rem] text-black font-jejuhallasan">
      <div className="relative inline-block w-[22.31rem] h-[3.38rem] shrink-0">
        Park’N Ride
      </div>
    </div>
  );
};

export default IPhone13141;
