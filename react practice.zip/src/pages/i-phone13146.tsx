import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import TwoWheelerCard from "../components/two-wheeler-card";

const IPhone13146: FunctionComponent = () => {
  const navigate = useNavigate();

  const onKeyboardArrowDownClick = useCallback(() => {
    navigate("/iphone-13-14-5");
  }, [navigate]);

  return (
    <div className="relative rounded-31xl bg-white w-full h-[52.75rem] overflow-auto text-left text-[1.69rem] text-black font-jost">
      <img
        className="absolute top-[32.69rem] left-[19.81rem] w-[3.38rem] h-[3.5rem] overflow-hidden cursor-pointer"
        alt=""
        src="/ellipse-1.svg"
        onClick={onKeyboardArrowDownClick}
      />
      <img
        className="absolute top-[0rem] left-[0rem] w-[80rem] h-[80rem] object-cover"
        alt=""
        src="/basemap-image@2x.png"
      />
      <img
        className="absolute top-[2.19rem] left-[1.44rem] rounded-169xl w-[10.75rem] h-[6.06rem] object-cover"
        alt=""
        src="/image-5@2x.png"
      />
      <TwoWheelerCard />
      <div className="absolute top-[26rem] left-[0rem] rounded-36xl bg-whitesmoke-100 w-[24.38rem] h-[27.13rem]" />
      <div className="absolute top-[28.24rem] left-[0.06rem] whitespace-pre-wrap inline-block w-[13.09rem] h-[4.93rem] [transform:_rotate(-0.86deg)] [transform-origin:0_0]">
        <p className="m-0">{` Sai krupa apts,   `}</p>
        <p className="m-0"> chikkadpally</p>
      </div>
      <div className="absolute top-[33.44rem] left-[0.06rem] inline-block w-[13.19rem] h-[5.44rem]">
        <p className="m-0">Subhash enclave,</p>
        <p className="m-0">near rtc metro</p>
      </div>
      <div className="absolute top-[39.56rem] left-[0rem] inline-block w-[12.38rem] h-[4.25rem]">
        <p className="m-0">Dark house cafe,</p>
        <p className="m-0">opp to pillar 5</p>
      </div>
      <div className="absolute top-[33.16rem] left-[-0.03rem] box-border w-[23.25rem] h-[0.06rem] border-t-[1px] border-solid border-black" />
      <div className="absolute top-[38.84rem] left-[-0.03rem] box-border w-[23.25rem] h-[0.06rem] border-t-[1px] border-solid border-black" />
      <div className="absolute top-[45.47rem] left-[-0.03rem] box-border w-[23.25rem] h-[0.06rem] border-t-[1px] border-solid border-black" />
      <img
        className="absolute top-[29rem] left-[15.31rem] w-[6.5rem] h-[2.88rem]"
        alt=""
        src="/ellipse-1.svg"
      />
      <div className="absolute top-[28.63rem] left-[15.13rem] whitespace-pre-wrap inline-block w-[6.88rem] h-[2.56rem] text-[1.25rem]">
        <p className="m-0">
          <span className="text-[1.69rem]">{`     `}</span>
          <span>50</span>
        </p>
        <p className="m-0">per hour</p>
      </div>
      <div className="absolute top-[34.44rem] left-[15.25rem] text-[1.25rem] whitespace-pre-wrap inline-block w-[4.75rem] h-[3.06rem]">
        <p className="m-0"> 40</p>
        <p className="m-0">per hour</p>
      </div>
      <div className="absolute top-[40.5rem] left-[15.44rem] text-[1.25rem] whitespace-pre-wrap inline-block w-[5.25rem] h-[3.31rem]">
        <p className="m-0"> 60</p>
        <p className="m-0">per hour</p>
      </div>
      <img
        className="absolute top-[29.06rem] left-[14.81rem] w-[2.81rem] h-[1.75rem] object-cover"
        alt=""
        src="/rupee@2x.png"
      />
      <img
        className="absolute top-[34.44rem] left-[14.81rem] w-[2.81rem] h-[1.75rem] object-cover"
        alt=""
        src="/rupee@2x.png"
      />
      <img
        className="absolute top-[40.44rem] left-[14.81rem] w-[2.81rem] h-[1.75rem] object-cover"
        alt=""
        src="/rupee@2x.png"
      />
      <div className="absolute top-[46.81rem] left-[0.56rem] w-[23.31rem] h-[3.88rem] text-[2.25rem]">
        <div className="absolute top-[0rem] left-[0rem] rounded-57xl bg-lightskyblue w-[23.19rem] h-[3.88rem]" />
        <div className="absolute top-[0.25rem] left-[3.88rem] inline-block w-[19.44rem] h-[2.5rem]">
          Book your spot
        </div>
      </div>
    </div>
  );
};

export default IPhone13146;
