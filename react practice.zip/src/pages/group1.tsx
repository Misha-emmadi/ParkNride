import { FunctionComponent } from "react";

const Group1: FunctionComponent = () => {
  return (
    <div className="relative w-full h-[52.75rem] text-left text-[1.5rem] text-black font-jost">
      <div className="absolute top-[0rem] left-[0rem] rounded-31xl bg-white w-[24.38rem] h-[52.75rem] overflow-hidden">
        <div className="absolute top-[-37.12rem] left-[-22.06rem] w-[58.94rem] h-[116.06rem]">
          <img
            className="absolute top-[37.13rem] left-[22.06rem] w-[58.94rem] h-[116.06rem] object-cover"
            alt=""
            src="/basemap-image1@2x.png"
          />
        </div>
        <img
          className="absolute top-[1.38rem] left-[1.44rem] rounded-169xl w-[10.75rem] h-[6.06rem] object-cover"
          alt=""
          src="/image-5@2x.png"
        />
        <div className="absolute top-[10.44rem] left-[0rem] rounded-50xl bg-gainsboro-100 w-[24.38rem] h-[5.75rem]" />
        <img
          className="absolute h-[2.05%] w-[6.92%] top-[24.17%] right-[7.44%] bottom-[73.78%] left-[85.64%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/vector4.svg"
        />
        <div className="absolute top-[11.75rem] left-[7.25rem] text-[2.25rem] font-istok-web inline-block w-[14.5rem] h-[3.13rem]">
          4 wheeler
        </div>
        <img
          className="absolute h-[5.81%] w-[13.85%] top-[21.21%] right-[80.26%] bottom-[72.99%] left-[5.9%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/vector1.svg"
        />
        <div className="absolute top-[26.38rem] left-[0rem] rounded-36xl bg-whitesmoke-100 w-[24.38rem] h-[27.13rem]" />
        <div className="absolute top-[47.81rem] left-[0.5rem] w-[23.31rem] h-[3.88rem] text-[2.25rem]">
          <div className="absolute top-[0rem] left-[0rem] rounded-57xl bg-lightskyblue w-[23.19rem] h-[3.88rem]" />
          <div className="absolute top-[0.25rem] left-[3.88rem] inline-block w-[19.44rem] h-[2.5rem]">
            Book your spot
          </div>
        </div>
        <img
          className="absolute top-[33.13rem] left-[0.5rem] w-[23.69rem] h-[0.19rem]"
          alt=""
          src="/ellipse-1.svg"
        />
        <img
          className="absolute top-[39.81rem] left-[0.5rem] w-[23.69rem] h-[0.19rem]"
          alt=""
          src="/ellipse-1.svg"
        />
        <div className="absolute top-[28.31rem] left-[1.5rem] inline-block w-[9.13rem] h-[4.31rem]">
          DSL Virtue mall, Uppal
        </div>
        <div className="absolute top-[34.13rem] left-[1.31rem] inline-block w-[10.81rem] h-[4.81rem]">
          <p className="m-0">Modern bakery,</p>
          <p className="m-0">Uppal</p>
        </div>
        <div className="absolute top-[40.13rem] left-[1.5rem] inline-block w-[6.94rem] h-[6.44rem]">
          Game point, Uppal
        </div>
        <div className="absolute top-[28.81rem] left-[14.88rem] whitespace-pre-wrap inline-block w-[7.69rem] h-[3.81rem]">
          <p className="m-0"> 100</p>
          <p className="m-0"> per hour</p>
        </div>
        <div className="absolute top-[34.5rem] left-[16.06rem] whitespace-pre-wrap inline-block w-[6.5rem] h-[4.44rem]">
          <p className="m-0"> 60</p>
          <p className="m-0">per hour</p>
        </div>
        <div className="absolute top-[40.69rem] left-[16rem] whitespace-pre-wrap inline-block w-[6.56rem] h-[5.44rem]">
          <p className="m-0"> 50</p>
          <p className="m-0">per hour</p>
        </div>
        <img
          className="absolute top-[29.06rem] left-[15.94rem] w-[2.81rem] h-[1.75rem] object-cover"
          alt=""
          src="/rupee@2x.png"
        />
        <img
          className="absolute top-[34.5rem] left-[16.06rem] w-[2.81rem] h-[1.75rem] object-cover"
          alt=""
          src="/rupee@2x.png"
        />
        <img
          className="absolute top-[41.19rem] left-[16.5rem] w-[2.81rem] h-[1.75rem] object-cover"
          alt=""
          src="/rupee@2x.png"
        />
      </div>
    </div>
  );
};

export default Group1;
