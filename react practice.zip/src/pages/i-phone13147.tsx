import { FunctionComponent } from "react";

const IPhone13147: FunctionComponent = () => {
  return (
    <div className="relative rounded-31xl bg-white w-full h-[52.75rem] overflow-hidden text-left text-[1.5rem] text-black font-jost">
      <img
        className="absolute top-[0rem] left-[0rem] w-[53.88rem] h-[52.75rem] object-cover"
        alt=""
        src="/basemap-image2@2x.png"
      />
      <img
        className="absolute top-[1.88rem] left-[1.44rem] rounded-169xl w-[10.75rem] h-[6.06rem] object-cover"
        alt=""
        src="/image-5@2x.png"
      />
      <div className="absolute top-[9.38rem] left-[0rem] rounded-50xl bg-gainsboro-100 w-[24.38rem] h-[5.75rem]" />
      <img
        className="absolute h-[5.81%] w-[13.85%] top-[20.38%] right-[78.21%] bottom-[73.82%] left-[7.95%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector1.svg"
      />
      <div className="absolute top-[10.56rem] left-[7rem] text-[2.25rem] font-istok-web inline-block w-[14.5rem] h-[3.13rem]">
        3 wheeler
      </div>
      <img
        className="absolute h-[2.05%] w-[6.92%] top-[21.92%] right-[8.33%] bottom-[76.03%] left-[84.74%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector5.svg"
      />
      <div className="absolute top-[26.38rem] left-[0rem] rounded-36xl bg-whitesmoke-100 w-[24.38rem] h-[27.13rem]" />
      <div className="absolute top-[47.56rem] left-[0.5rem] w-[23.31rem] h-[3.88rem] text-[2.25rem]">
        <div className="absolute top-[0rem] left-[0rem] rounded-57xl bg-lightskyblue w-[23.19rem] h-[3.88rem]" />
        <div className="absolute top-[0.25rem] left-[3.88rem] inline-block w-[19.44rem] h-[2.5rem]">
          Book your spot
        </div>
      </div>
      <div className="absolute top-[27.81rem] left-[0.5rem] text-[1.75rem] inline-block w-[12.19rem] h-[3.75rem]">
        <p className="m-0">Satva mall</p>
        <p className="m-0">ameerpet</p>
      </div>
      <img
        className="absolute top-[32.88rem] left-[0rem] w-[23.69rem] h-[0.19rem]"
        alt=""
        src="/ellipse-1.svg"
      />
      <img
        className="absolute top-[39.81rem] left-[0.13rem] w-[23.69rem] h-[0.19rem]"
        alt=""
        src="/ellipse-1.svg"
      />
      <div className="absolute top-[28.63rem] left-[15.25rem] whitespace-pre-wrap inline-block w-[7.13rem] h-[3.56rem]">
        <p className="m-0"> 60</p>
        <p className="m-0">per hour</p>
      </div>
      <div className="absolute top-[34.31rem] left-[0rem] inline-block w-[12.19rem] h-[4.69rem]">
        <p className="m-0">AK apts,</p>
        <p className="m-0">Ameerpet</p>
      </div>
      <div className="absolute top-[40.81rem] left-[0rem] inline-block w-[8.63rem] h-[5rem]">
        Street ball mall, ameerpet
      </div>
      <div className="absolute top-[34.31rem] left-[15.25rem] whitespace-pre-wrap inline-block w-[7.13rem] h-[4.69rem]">
        <p className="m-0"> 50</p>
        <p className="m-0">per hour</p>
      </div>
      <div className="absolute top-[41.25rem] left-[15.25rem] whitespace-pre-wrap inline-block w-[8.44rem] h-[5.56rem]">
        <p className="m-0"> 50</p>
        <p className="m-0">per hour</p>
      </div>
      <img
        className="absolute top-[28.94rem] left-[15.25rem] w-[2.81rem] h-[1.75rem] object-cover"
        alt=""
        src="/rupee@2x.png"
      />
      <img
        className="absolute top-[41.25rem] left-[15.25rem] w-[2.81rem] h-[1.75rem] object-cover"
        alt=""
        src="/rupee@2x.png"
      />
      <img
        className="absolute top-[34.31rem] left-[15.25rem] w-[2.81rem] h-[1.75rem] object-cover"
        alt=""
        src="/rupee@2x.png"
      />
    </div>
  );
};

export default IPhone13147;
