import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const IPhone13144: FunctionComponent = () => {
  const navigate = useNavigate();

  const onRectangle2Click = useCallback(() => {
    navigate("/iphone-13-14-5");
  }, [navigate]);

  const onKeyboardArrowDownClick = useCallback(() => {
    navigate("/iphone-13-14-5");
  }, [navigate]);

  return (
    <div className="relative rounded-31xl bg-white w-full h-[52.75rem] overflow-hidden text-left text-[2.25rem] text-black font-istok-web">
      <div className="absolute top-[2.69rem] left-[-0.06rem] w-[24.44rem] h-[34.81rem]">
        <div className="absolute top-[8.31rem] left-[0.06rem] rounded-26xl bg-black w-[24.38rem] h-[9.5rem]" />
        <div className="absolute top-[10.81rem] left-[2.31rem] text-white inline-block w-[19.88rem] h-[5.44rem]">
          <p className="m-0">Welcome....</p>
          <p className="m-0">Nandini</p>
        </div>
        <div className="absolute top-[19.94rem] left-[0.06rem] rounded-50xl bg-gainsboro-100 w-[24.38rem] h-[5.75rem]" />
        <div
          className="absolute top-[29.06rem] left-[0.06rem] rounded-50xl bg-gainsboro-100 w-[24.38rem] h-[5.75rem] cursor-pointer"
          onClick={onRectangle2Click}
        />
        <div className="absolute top-[21.44rem] left-[5.88rem] inline-block w-[17.38rem] h-[5.5rem]">
          Current location
        </div>
        <img
          className="absolute h-[10.41%] w-[12.53%] top-[60.32%] right-[78.01%] bottom-[29.26%] left-[9.46%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/vector.svg"
        />
        <img
          className="absolute h-[8.8%] w-[13.81%] top-[87.43%] right-[78.01%] bottom-[3.77%] left-[8.18%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/vector1.svg"
        />
        <div className="absolute top-[29.19rem] left-[7.06rem] inline-block w-[15.13rem] h-[5.63rem]">
          Choose the type of vehicle
        </div>
        <img
          className="absolute top-[30rem] left-[19.88rem] w-[3.38rem] h-[3.5rem] overflow-hidden cursor-pointer"
          alt=""
          src="/keyboard-arrow-down.svg"
          onClick={onKeyboardArrowDownClick}
        />
        <img
          className="absolute top-[0rem] left-[0.06rem] rounded-169xl w-[10.75rem] h-[6.06rem] object-cover"
          alt=""
          src="/image-5@2x.png"
        />
      </div>
    </div>
  );
};

export default IPhone13144;
