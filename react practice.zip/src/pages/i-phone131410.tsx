import { FunctionComponent } from "react";

const IPhone131410: FunctionComponent = () => {
  return (
    <div className="relative rounded-41xl bg-lightblue w-full h-[52.75rem] overflow-hidden text-left text-[2.25rem] text-black font-jost">
      <div className="absolute top-[1.25rem] left-[0rem] w-[24.38rem] h-[34.88rem]">
        <img
          className="absolute top-[0rem] left-[1.44rem] rounded-169xl w-[10.75rem] h-[6.06rem] object-cover"
          alt=""
          src="/image-5@2x.png"
        />
        <div className="absolute top-[22.25rem] left-[0rem] rounded-60xl bg-mistyrose w-[24.38rem] h-[5.75rem]" />
        <img
          className="absolute top-[22.31rem] left-[2.88rem] w-[6.25rem] h-[6.25rem]"
          alt=""
          src="/ellipse-1.svg"
        />
        <div className="absolute top-[29.06rem] left-[0rem] rounded-60xl bg-mistyrose w-[24.38rem] h-[5.81rem]" />
        <div className="absolute top-[23.19rem] left-[4.06rem] inline-block w-[16.88rem] h-[4rem]">
          o
        </div>
        <div className="absolute top-[23.19rem] left-[3.88rem] inline-block w-[18.25rem] h-[2.88rem]">
          Online payment
        </div>
        <div className="absolute top-[30.38rem] left-[3.13rem] inline-block w-[15.94rem] h-[1.75rem]">
          Cash payment
        </div>
        <div className="absolute top-[10.88rem] left-[2.44rem] inline-block w-[18.5rem] h-[8.44rem]">
          <p className="m-0">Park,Pay,</p>
          <p className="m-0">Be on your way..</p>
        </div>
      </div>
    </div>
  );
};

export default IPhone131410;
