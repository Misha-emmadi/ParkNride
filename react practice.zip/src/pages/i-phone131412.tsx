import { FunctionComponent } from "react";

const IPhone131412: FunctionComponent = () => {
  return (
    <div className="relative rounded-41xl bg-lightblue w-full h-[52.75rem] overflow-hidden text-left text-[2.25rem] text-black font-jost">
      <div className="absolute top-[1.25rem] left-[1.25rem] w-[21.81rem] h-[38.19rem]">
        <img
          className="absolute top-[0rem] left-[0.19rem] rounded-169xl w-[10.75rem] h-[6.06rem] object-cover"
          alt=""
          src="/image-5@2x.png"
        />
        <img
          className="absolute top-[22.31rem] left-[2.88rem] w-[6.25rem] h-[6.25rem]"
          alt=""
          src="/ellipse-1.svg"
        />
        <div className="absolute top-[23.19rem] left-[2.81rem] inline-block w-[16.88rem] h-[4rem]">
          o
        </div>
        <div className="absolute top-[14.88rem] left-[1.19rem] inline-block w-[18.5rem] h-[4.44rem]">
          Parking slot details
        </div>
        <div className="absolute top-[19.31rem] left-[0rem] rounded-24xl bg-gainsboro-100 w-[21.81rem] h-[18.88rem]" />
        <div className="absolute top-[21.75rem] left-[1.63rem] inline-block w-[18.06rem] h-[16.44rem]">
          <p className="m-0">{`Slot booked for 4 wheeler `}</p>
          <p className="m-0">DSL virtue mall,</p>
          <p className="m-0">Uppal</p>
          <p className="m-0">Parking no: 304 A</p>
        </div>
        <div className="absolute top-[8.13rem] left-[0.19rem] inline-block w-[21.63rem] h-[5rem]">
          Payment confirmed
        </div>
      </div>
    </div>
  );
};

export default IPhone131412;
