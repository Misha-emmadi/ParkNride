import { FunctionComponent } from "react";

const IPhone13145: FunctionComponent = () => {
  return (
    <div className="relative rounded-31xl bg-white w-full h-[52.75rem] overflow-hidden text-left text-[2.25rem] text-black font-istok-web">
      <div className="absolute top-[11rem] left-[0rem] rounded-26xl bg-black w-[24.38rem] h-[9.5rem]" />
      <div className="absolute top-[13.5rem] left-[2.25rem] text-white inline-block w-[19.88rem] h-[5.44rem]">
        <p className="m-0">Welcome....</p>
        <p className="m-0">Nandini</p>
      </div>
      <div className="absolute top-[22.63rem] left-[0rem] rounded-50xl bg-gainsboro-100 w-[24.38rem] h-[5.75rem]" />
      <div className="absolute top-[31.75rem] left-[0rem] rounded-50xl bg-gainsboro-100 w-[24.38rem] h-[5.75rem]" />
      <div className="absolute top-[24.13rem] left-[5.81rem] inline-block w-[17.38rem] h-[5.5rem]">
        Current location
      </div>
      <img
        className="absolute h-[6.87%] w-[12.56%] top-[44.91%] right-[78.21%] bottom-[48.22%] left-[9.23%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector.svg"
      />
      <img
        className="absolute h-[5.81%] w-[13.85%] top-[62.8%] right-[78.21%] bottom-[31.4%] left-[7.95%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector1.svg"
      />
      <div className="absolute top-[31.88rem] left-[7rem] inline-block w-[15.13rem] h-[5.63rem]">
        Choose the type of vehicle
      </div>
      <img
        className="absolute top-[32.69rem] left-[19.81rem] w-[3.38rem] h-[3.5rem] overflow-hidden"
        alt=""
        src="/keyboard-arrow-down.svg"
      />
      <div className="absolute top-[34.81rem] left-[0rem] bg-lightgray w-[24.38rem] h-[14.13rem] mix-blend-multiply" />
      <div className="absolute top-[36.63rem] left-[0rem] text-[3rem] font-inria-sans whitespace-pre-wrap inline-block w-[23.19rem] h-[5.25rem]">
        <p className="m-0"> Two wheeler</p>
        <p className="m-0"> 3 wheeler</p>
        <p className="m-0"> 4 wheeler</p>
      </div>
      <img
        className="absolute top-[2.81rem] left-[0rem] rounded-169xl w-[10.75rem] h-[6.06rem] object-cover"
        alt=""
        src="/image-5@2x.png"
      />
    </div>
  );
};

export default IPhone13145;
