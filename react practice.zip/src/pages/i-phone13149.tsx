import { FunctionComponent } from "react";

const IPhone13149: FunctionComponent = () => {
  return (
    <div className="relative rounded-41xl bg-lightblue w-full h-[52.75rem] overflow-hidden text-left text-[2.25rem] text-black font-jost">
      <div className="absolute top-[1.25rem] left-[-0.12rem] w-[24.5rem] h-[44.63rem]">
        <img
          className="absolute top-[0rem] left-[1.56rem] rounded-169xl w-[10.75rem] h-[6.06rem] object-cover"
          alt=""
          src="/image-5@2x.png"
        />
        <div className="absolute top-[7.31rem] left-[1.94rem] inline-block w-[20.44rem] h-[4.44rem]">
          {" "}
          Parking timer
        </div>
        <div className="absolute top-[30.5rem] left-[0.13rem] rounded-60xl bg-mistyrose w-[24.38rem] h-[5.81rem]" />
        <div className="absolute top-[38.81rem] left-[0rem] rounded-60xl bg-mistyrose w-[24.38rem] h-[5.81rem]" />
        <div className="absolute top-[31.44rem] left-[6.5rem] inline-block w-[17.88rem] h-[4rem]">
          Finish parking
        </div>
        <div className="absolute top-[39.5rem] left-[4.88rem] inline-block w-[14.81rem] h-[4.5rem]">
          Extend timer
        </div>
        <img
          className="absolute top-[13rem] left-[5.88rem] w-[12.56rem] h-[14.69rem] object-cover"
          alt=""
          src="/image-6@2x.png"
        />
      </div>
    </div>
  );
};

export default IPhone13149;
