import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const IPhone131411: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameContainerClick = useCallback(() => {
    navigate("/iphone-13-14-2");
  }, [navigate]);

  return (
    <div className="relative rounded-29xl bg-lightblue w-full h-[52.75rem] overflow-hidden text-left text-[3rem] text-black font-jejuhallasan">
      <div className="absolute top-[0rem] left-[0rem] w-[25.44rem] h-[49.81rem]">
        <div className="absolute top-[0rem] left-[0rem] rounded-30xl bg-lightcyan w-[24.38rem] overflow-hidden flex flex-col items-end justify-start py-[3.31rem] px-[0rem] box-border">
          <div className="relative w-[22.31rem] h-[3.38rem]">
            <div className="absolute top-[0rem] left-[0rem] w-[22.31rem] h-[3.38rem]">
              <div className="absolute top-[0rem] left-[0rem] inline-block w-[22.31rem] h-[3.38rem]">
                Park’N Ride
              </div>
            </div>
          </div>
        </div>
        <div className="absolute top-[12.44rem] left-[1.06rem] w-[24.38rem] h-[22.31rem]">
          <img
            className="absolute top-[0rem] left-[0rem] w-[24.38rem] h-[22.31rem]"
            alt=""
            src="/vector2.svg"
          />
          <img
            className="absolute top-[0rem] left-[0.69rem] w-[23.69rem] h-[19.31rem] object-cover"
            alt=""
            src="/cityscapes-downtown@2x.png"
          />
        </div>
        <div className="absolute top-[46.13rem] left-[2.06rem] w-[21rem] h-[3.69rem] text-[2rem] text-white font-irish-grover">
          <div
            className="absolute top-[0rem] left-[0rem] rounded-11xl bg-cornflowerblue w-[21rem] h-[3.69rem] overflow-hidden cursor-pointer"
            onClick={onFrameContainerClick}
          >
            <div className="absolute top-[0.63rem] left-[1.5rem] w-[14.75rem] h-[2.44rem]">
              <div className="absolute top-[0rem] left-[0rem] inline-block w-[14.75rem] h-[2.44rem]">
                Get started
              </div>
            </div>
            <img
              className="absolute h-[59.15%] w-[15.48%] top-[23.9%] right-[7.14%] bottom-[16.95%] left-[77.38%] max-w-full overflow-hidden max-h-full"
              alt=""
              src="/vector3.svg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default IPhone131411;
