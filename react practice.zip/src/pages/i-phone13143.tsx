import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const IPhone13143: FunctionComponent = () => {
  const navigate = useNavigate();

  const onRectangle1Click = useCallback(() => {
    navigate("/iphone-13-14-4");
  }, [navigate]);

  return (
    <div className="relative rounded-29xl bg-black w-full h-[52.75rem] overflow-hidden text-left text-[1.75rem] text-black font-istok-web">
      <div className="absolute top-[4.06rem] left-[0rem] w-[24.38rem] h-[48.69rem]">
        <div className="absolute top-[10rem] left-[0rem] rounded-24xl bg-gainsboro-100 w-[24.38rem] h-[38.69rem]" />
        <div className="absolute top-[15.38rem] left-[2.75rem] inline-block w-[18.81rem] h-[3.38rem]">
          Enter OTP
        </div>
        <div className="absolute top-[19.44rem] left-[2.75rem] inline-block w-[19.81rem] h-[3.56rem]">
          _ _ _ _
        </div>
        <div
          className="absolute top-[41.44rem] left-[2.06rem] rounded-11xl bg-cornflowerblue w-[20.19rem] h-[3.81rem] cursor-pointer"
          onClick={onRectangle1Click}
        />
        <div className="absolute top-[42.13rem] left-[4.81rem] text-[2rem] font-irish-grover text-white inline-block w-[11.19rem] h-[2.44rem]">
          <p className="m-0">Continue</p>
        </div>
        <img
          className="absolute h-[4.48%] w-[13.33%] top-[86.52%] right-[12.05%] bottom-[9%] left-[74.62%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/-icon-chevron-right.svg"
        />
        <div className="absolute top-[0rem] left-[3.5rem] text-[3rem] font-jejuhallasan text-white inline-block w-[19.69rem] h-[3.75rem]">
          Park’N Ride
        </div>
      </div>
    </div>
  );
};

export default IPhone13143;
