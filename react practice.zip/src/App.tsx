import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import IPhone131411 from "./pages/i-phone131411";
import IPhone13142 from "./pages/i-phone13142";
import IPhone13143 from "./pages/i-phone13143";
import IPhone13144 from "./pages/i-phone13144";
import IPhone13145 from "./pages/i-phone13145";
import IPhone13146 from "./pages/i-phone13146";
import IPhone13147 from "./pages/i-phone13147";
import IPhone13148 from "./pages/i-phone13148";
import IPhone13149 from "./pages/i-phone13149";
import IPhone131410 from "./pages/i-phone131410";
import IPhone131412 from "./pages/i-phone131412";
import Group1 from "./pages/group1";
import Group2 from "./pages/group2";
import Group3 from "./pages/group3";
import IPhone13141 from "./pages/i-phone13141";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-2":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-3":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-4":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-5":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-6":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-7":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-8":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-9":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-10":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-12":
        title = "";
        metaDescription = "";
        break;
      case "/group-16":
        title = "";
        metaDescription = "";
        break;
      case "/group-17":
        title = "";
        metaDescription = "";
        break;
      case "/group-18":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-14-1":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<IPhone131411 />} />
      <Route path="/iphone-13-14-2" element={<IPhone13142 />} />
      <Route path="/iphone-13-14-3" element={<IPhone13143 />} />
      <Route path="/iphone-13-14-4" element={<IPhone13144 />} />
      <Route path="/iphone-13-14-5" element={<IPhone13145 />} />
      <Route path="/iphone-13-14-6" element={<IPhone13146 />} />
      <Route path="/iphone-13-14-7" element={<IPhone13147 />} />
      <Route path="/iphone-13-14-8" element={<IPhone13148 />} />
      <Route path="/iphone-13-14-9" element={<IPhone13149 />} />
      <Route path="/iphone-13-14-10" element={<IPhone131410 />} />
      <Route path="/iphone-13-14-12" element={<IPhone131412 />} />
      <Route path="/group-16" element={<Group1 />} />
      <Route path="/group-17" element={<Group2 />} />
      <Route path="/group-18" element={<Group3 />} />
      <Route path="/iphone-13-14-1" element={<IPhone13141 />} />
    </Routes>
  );
}
export default App;
